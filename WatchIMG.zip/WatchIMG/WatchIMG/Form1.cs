﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WatchIMG
{
    public partial class Form1 : Form
    {
        private int pbh, // исходная высота и
                    pbw; // ширина элемента pictureBox1
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // запоминаем исходные значения высоты и ширины
            // компонента pictureBox1
            pbh = pictureBox1.Height;
            pbw = pictureBox1.Width;
            // элементы listBox1 сортируются в
            // алфавитном порядке
            listBox1.Sorted = true;
            // Application.StartupPath возвращает путь к каталогу,
            // из которого была запущена программа;
            // заполняем listBox1 списком иллюстраций
            FillListBox(Application.StartupPath + "\\");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // диалоговое окно выбора каталога
            FolderBrowserDialog fb
            = new FolderBrowserDialog();
            fb.Description = "Выберите папку";
            fb.ShowNewFolderButton = false;
                // отображаем диалоговое окно
                if (fb.ShowDialog() == DialogResult.OK)
                // пользователь выбрал каталог и
                // щелкнул на кнопке OK
                if (!FillListBox(fb.SelectedPath + "\\"))
                    // в каталоге нет файлов, выгружаем
                    // из pictureBox1 ранее отображаемый файл
                    pictureBox1.Image = null;
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            double mh, mw; // коэффициенты масштабирования
                           // загружаем изображение в pictureBox1
            pictureBox1.Image =
            new Bitmap(textBox1.Text +
            listBox1.SelectedItem.ToString());
            // масштабируем, если нужно
            if ((pictureBox1.Image.Width > pbw) ||
            (pictureBox1.Image.Height > pbh))
            {
                pictureBox1.SizeMode =
                PictureBoxSizeMode.StretchImage;
                mh = (double)pbh / (double)pictureBox1.Image.Height;
                mw = (double)pbw / (double)pictureBox1.Image.Width;
                if (mh < mw)
                {
                    // масштабируем по ширине
                    pictureBox1.Width = Convert.ToInt16(
                    pictureBox1.Image.Width * mh);
                    pictureBox1.Height = pbh;
                }
 else
                {
                    // масштабируем по высоте
                    pictureBox1.Width = pbw;
                    pictureBox1.Height = Convert.ToInt16(
                    pictureBox1.Image.Height * mw);
                }
            }
            else
            // если предыдущее изображение масштабировалось
            if (pictureBox1.SizeMode ==
            PictureBoxSizeMode.StretchImage)
                pictureBox1.SizeMode =
                PictureBoxSizeMode.AutoSize;

        }

        private Boolean FillListBox(string aPath)
        {
            // информация о каталоге
            DirectoryInfo di =
            new DirectoryInfo(aPath);
            // массив информации о файлах
            FileInfo[] fi = di.GetFiles("*.jpg");
            // очищаем ранее полученный список файлов
            listBox1.Items.Clear();
            // добавляем в listBox1 имена jpg-файлов,
            // содержащихся в каталоге aPath
            foreach (FileInfo fc in fi)
            {
                listBox1.Items.Add(fc.Name);
            }

             textBox1.Text = aPath;
            if (fi.Length == 0) return false;
            else
            {
                // выбираем первый файл из полученного списка
                listBox1.SelectedIndex = 0;
                return true;
            }
        }

    }
}
