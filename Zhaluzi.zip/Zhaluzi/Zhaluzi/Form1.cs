﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Zhaluzi
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // делаем недоступной кнопку Ok
            button1.Enabled = false;
            // материал по умолчанию - алюминий
            radioButton1.Checked = true;
        }
        // нажатие клавиши в поле Ширина
        private void textBox1_KeyPress(object sender,
        System.Windows.Forms.KeyPressEventArgs e)
        {

        }
        // нажатие клавиши в поле Высота
        private void textBox2_KeyPress(object sender,
        System.Windows.Forms.KeyPressEventArgs e)
        {
            // контроль правильности вводимых данных
            if (!Char.IsDigit(e.KeyChar) &&
            !(Char.IsControl(e.KeyChar)))
                if (!((e.KeyChar.ToString() == ",") &&
                (textBox2.Text.IndexOf(",") == -1)))
                    e.Handled = true;
        }
        // изменение содержимого полей Ширина и Высота;
        // процедура обработки создается для поля Ширина
        // после чего назначается как процедура обработки
        // и для поля Высота
        private void textBox1_TextChanged(object sender,
        System.EventArgs e)
        {
            // проверка, нужно ли блокировать кнопку Ok
            if ((textBox1.TextLength == 0) ||
            (textBox2.TextLength == 0) ||
            (textBox1.Text == ",") ||
            (textBox2.Text == ","))
                button1.Enabled = false;
            else button1.Enabled = true;
        }
        // щелчок на кнопке Ok
        private void button1_Click(object sender, System.EventArgs e)
        {
            Single w, h, s, // ширина, высота и площадь
            c, // цена за 1 кв.м.
            cst; // стоимость
            w = Convert.ToSingle(textBox1.Text);
            h = Convert.ToSingle(textBox2.Text);
            s = w * h / 10000;
            if (radioButton1.Checked)
                c = 3600; // выбран переключатель "алюминий"
            else
                c = 1800; // выбран переключатель "пластик"
            cst = s * c;
            if (radioButton1.Checked)
                label3.Text = "Размер: " + w.ToString("N") +
                " x " + h.ToString("N") + " см\n" +
                "Материал: " + radioButton1.Text +
                "\nСтоимость: " + cst.ToString("C");
            else
                label3.Text = "Размер: " + w.ToString("N") + " x " + h.ToString("N") + " см\n" +
 "Материал: " + radioButton2.Text +
 "\nСтоимость: " + cst.ToString("C");
        }


    }
    }
