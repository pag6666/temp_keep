﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TimerJune
{
    enum TimerState { Stop, Launched };


    public partial class Form1 : Form
    {
        TimerState state = TimerState.Stop;
      

        TimeSpan time;//для отстчёта прошедшего времени

        public Form1()
        {
            InitializeComponent();
             //btnStart.enabled = false;
                //btnStart.text = "пуск";
                //numSec.Enabled = true;
                //numMin.Enabled = true;
                //state = TimerState.Stop;
                //time = new TimeSpan(0, (int)numMin.Value, (int)numSec.Value);
                //time = time.Add(new TimeSpan(0, 0, 0, 0, -190));
                //lblTimer.Text = string.Format("{0:t}", time);


        }

        private void numMin_ValueChanged(object sender, EventArgs e)
        {
            if (state == TimerState.Launched)
            {

            }
            else if (state == TimerState.Stop)
            {
                if(numMin.Value == 0 && numSec.Value == 0)
                    btnStart.Enabled = false;
                else
                    btnStart.Enabled = true;
            }
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            if (state == TimerState.Launched)
            {
                btnStart.Text = "Пуск";
                numSec.Enabled = true;
                numMin.Enabled = true;
                state = TimerState.Stop;
                numMin.Value = time.Minutes;
                numSec.Value = time.Seconds;
            }
            else if (state == TimerState.Stop)
            {

                btnStart.Text = "Стоп";
                numSec.Enabled = false;
                numMin.Enabled = false;
                state = TimerState.Launched;
                time = new TimeSpan(0, (int)numMin.Value, (int)numSec.Value);
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (state == TimerState.Launched)
            {                
                time = time.Add(new TimeSpan(0, 0, -1));
                lblTimer.Text = time.ToString(@"mm\:ss");
                if(time == TimeSpan.Zero)
                {
                    state = TimerState.Stop;
                    MessageBox.Show("Заданный интервал времени истек", "Таймер");
                    btnStart.Enabled = false;
                    btnStart.Text = "пуск";
                    numSec.Enabled = true;
                    numMin.Enabled = true;                    
                    numMin.Value = 0;
                    numSec.Value = 0;
                   
                }
            }
            else if (state == TimerState.Stop)
            {
                
            }
        }
    }
}
