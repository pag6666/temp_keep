using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace sekundomer
{
    enum TimerState { Stop, Launched};


    public partial class frmTimer : Form
    {
        TimerState state = TimerState.Stop;

        TimeSpan time;//��� �������� ���������� �������

        public frmTimer()
        {
            InitializeComponent();
            //if (numMin.Value == 0 && numSec.Value == 0)
            //btnStart.Enabled = false;
            //btnStart.Text = "����";
            //numSec.Enabled = true;
            //numMin.Enabled = true;
            //state = TimerState.Stop;
            //time = new TimeSpan(0, (int)numMin.Value, (int)numSec.Value);
            //time = time.Add(new TimeSpan(0, 0, 0, 0, -190));
            //lblTimer.Text = string.Format("{0:t}", time);
        }

        private void numMin_ValueChanged(object sender, EventArgs e)
        {
            if (state == TimerState.Launched)
            { 
            }
            else if (state == TimerState.Stop)
            {
            }             
        }


        


    }
}